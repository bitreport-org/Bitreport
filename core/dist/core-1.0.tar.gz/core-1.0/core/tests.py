import requests

# for _ in range(5):
#     internal.update_events()
#
# print(get('http://localhost:5000/events').json())
# print(get('http://localhost:5000/data/BTCUSD/1h/?limit=10&indicators=HTphasor').json())





# close = internal.import_numpy('BTCUSD', '3h',30)['close'][1:21]
# open = internal.import_numpy('BTCUSD', '3h',30)['open'][1:21]
# print(close)
#
# print(internal.check_dildo(close, open))

# print('Working . . .')
# while True:
#     now = int(time.mktime(datetime.datetime.now().timetuple()))
#     if now % (60*30) == 0:
#         # Wait to perform queries
#         time.sleep(2)
#
#         # check events
#         internal.update_events()
#
#         # sleep for next 29 minutes
#         time.sleep(60*29)
#
#     time.sleep(1)

url = 'http://localhost:5000/fill/BTCUSD/1h'
request = requests.post(url)
print(request)


# rp 1514555040000000000
# no 1514555040000000000